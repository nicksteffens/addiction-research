ChangeLog
---------

#### Version 1.2.0 (17.02.2016)
- White-list swizzling through APPAppEventDelegate protocol (#5)
- Finally fixed `EXC_BAD_ACCESS error` (#4)
- Removed usage of `nullable` to prevent build failures

#### Version 1.1.0 (02.01.2016)
- Fixed `EXC_BAD_ACCESS error`

#### Version 1.0.0 (01.01.2016)
- Initial version
